﻿using System;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Notebook.DLL.Context
{
    public class NotebookContext : IdentityDbContext<IdentityUser>
    {
        public DbSet<Note> Notes { get; set; }
        public NotebookContext(DbContextOptions<NotebookContext> options) : base(options)
        {
           // Database.EnsureCreated();
        }

        public NotebookContext()
        {
            //Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {

        }

    }
}

