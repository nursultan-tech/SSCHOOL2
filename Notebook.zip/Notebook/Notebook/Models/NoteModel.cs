﻿using System;
namespace Notebook.Models
{
    public class NoteModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}

