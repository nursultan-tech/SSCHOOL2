﻿using System;
namespace Notebook.Models
{
    public static class RolesInfo
    {
        public const string Manager = "manager";
        public const string User = "user";
    }
}

