﻿using System;
namespace Notebook.Modules
{
    public class Meta
    {
        public int PagesCount { get; set; }
        public int TotalItemsCount { get; set; }
    }
    public class MetaData<T>
    {
        public IQueryable<T> Data { get; set; }
        public Meta Meta { get; set; }
    }
}

