﻿using System;
using Microsoft.AspNetCore.Mvc;
using Notebook.DLL.Context;
using Notebook.Models;
using Notebook.Modules;
using Notebook.Services;

namespace Notebook.Controllers
{
    [ApiController]
    [Route("api/note")]
    public class NoteController
    {
        private NoteBookService service;
        public NoteController(NoteBookService service)
        {
            this.service = service;
        }
        [HttpPost]
        public async Task CreateAsync(NoteModel model)
        {
            await service.CreateAsync(model);
        }
        [HttpGet]
        public async Task<MetaData<Note>> GetPageAsync(int page, int count)
        {
            return await service.GetPageAsync(page, count);
        }

        [HttpGet("{id}")]
        public async Task<Note> GetAsync(int id)
        {
            return await service.GetAsync(id);
        }

        [HttpPut]
        public async Task<Note> UpdateAsync(Note entity)
        {
            return await service.UpdateAsync(entity);
        }

        [HttpDelete]
        public async Task DeleteAsync(int id)
        {
            await service.DeleteAsync(id);
        }
    }
}

