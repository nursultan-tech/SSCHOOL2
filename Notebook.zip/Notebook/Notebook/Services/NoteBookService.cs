﻿using System;
using Notebook.DLL.Context;
using Notebook.Models;
using Notebook.Modules;

namespace Notebook.Services
{
    public class NoteBookService
    {
        private NotebookContext context { get; }
        public NoteBookService(NotebookContext context)
        {
            this.context = context;
        }

        public async Task CreateAsync(NoteModel model)
        {
            var entity = new Note()
            {
                Name = model.Name,
                Description = model.Description
            };

            await context.Notes.AddAsync(entity);
            await context.SaveChangesAsync();
        }

        public async Task<MetaData<Note>> GetPageAsync(int page, int count)
        {
            var notes = context.Notes;
            var totalItems = context.Notes.Count();
            var pagesCount = totalItems / count;

            if (totalItems % count != 0)
            {
                pagesCount += 1;
            }

            Meta meta = new Meta
            {
                PagesCount = pagesCount,
                TotalItemsCount = totalItems
            };

            MetaData<Note> metadata = new MetaData<Note>
            {
                Data = notes.Skip((page - 1) * count).Take(count),
                Meta = meta
            };
            return await Task.FromResult(metadata);
        }

        public async Task<Note> GetAsync(int id)
        {
            var note = await context.Notes.FindAsync(id);
            if (note == null)
            {
                throw new Exception("No such element");
            }
            else
            {
                return await context.Notes.FindAsync(id);
            }
        }

        public async Task<Note> UpdateAsync(Note entity)
        {
            var note = await context.Notes.FindAsync(entity.Id);
            if (note == null)
            {
                throw new Exception("No such element");
            }
            else
            {
                note.Name = entity.Name;
                note.Description = entity.Description;
                await context.SaveChangesAsync();
                return await Task.FromResult(note);
            }
        }

        public async Task DeleteAsync(int id)
        {
            var note = await context.Notes.FindAsync(id);
            if (note == null)
            {
                throw new Exception("No such element");
            }
            else
            {
                await Task.FromResult(context.Notes.Remove(note));
                await context.SaveChangesAsync();
            }
        }
    }
}

