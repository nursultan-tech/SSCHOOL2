﻿using Microsoft.EntityFrameworkCore;
using Notebook.DLL.Context;
using Notebook.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddDbContext<NotebookContext>(s => s.UseSqlServer(builder.Configuration.GetConnectionString("NotebookContext")));
builder.Services.AddControllers();
builder.Services.AddTransient<NoteBookService>();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

